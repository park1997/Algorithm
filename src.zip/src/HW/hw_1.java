package HW;

import java.util.Scanner;

public class hw_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long num = sc.nextInt();
        long result = num*(num + 1) / 2;
        System.out.println(result);


    }
}
